# 亚马逊美国站环保Logo与认证合规知识库

> **版本**：V1.0｜2026-10-13  
> **适用范围**：Amazon US产品开发、供应商审核、包装及Listing环保声明、Climate Pledge Friendly（CPF）资格预审。  
> **证据规则**：本文区分【官方已核实】【需进一步确认】【商业建议】。法律与平台政策会变化，正式印刷或提交认证前须复核。  
> **图片声明**：本文八张Logo均从用户提供的图片裁切，用于内部识别和学习；**不是认证机构授权的印刷母版**。官方标志的正确版本、使用许可及编号须向权利人取得。未能可靠取得可供本地引用的官方图档，因此未擅自将网络上相似的图案当作官方文件。

![原始八标志总览](images/original_8_logos.png)

## 第一章｜环保认证基础知识

### 1.1 四个概念必须分开

1. **技术标准**：例如ASTM D6400、ASTM D6868、NF T51-800、AS 5810，规定测试及评价要求；“符合标准”不等于获得某个认证机构的商标许可。
2. **检测报告**：对特定材料或样品进行检测；需核查样品、厚度、配方、测试条件和报告适用范围。
3. **第三方认证**：机构依据其认证方案核查产品、工厂或供应链，颁发可验证证书，通常有型号和有效期限制。
4. **Logo商标授权**：允许在规定的产品、包装或广告上使用特定标志；拿到报告或供应商证书并不自动取得授权。

### 1.2 环保术语对照

| 英文 | 中文 | 关键边界 |
|---|---|---|
| Compostable | 可堆肥 | 必须明确家庭/商业堆肥条件、时间、残留及适用处理设施；并非自然环境都能降解 |
| Home compostable | 家庭可堆肥 | 相对较低温的受控家庭堆肥条件，不能由工业堆肥认证直接推出 |
| Biodegradable | 可生物降解 | 需要说明环境和证据；不等于可堆肥、可回收 |
| Recyclable | 可回收 | 材料可技术回收≠消费者当地实际可回收 |
| Recycled content | 再生材料含量 | 表示材料来源比例，不等于成品可回收 |
| FSC-certified | FSC认证 | 森林来源材料及产销监管链；不是降解或堆肥认证 |

**美国FTC要点【官方已核实】**：笼统的“Eco-friendly/Green”声明很难充分证实。对于通常作为固体废弃物处理的产品，未经限定的可降解声明需要证明整个产品在通常处置后一年内完全分解；回收设施覆盖不到至少60%消费者或社区时，通常需要对“可回收”声明加限定。[FTC Green Guides摘要](https://www.ftc.gov/business-guidance/resources/environmental-claims-summary-green-guides)。

## 第二章｜原图8个环保Logo逐一解析

### 2.1 ① Compostable（黑色幼苗图案）

![原图1：Compostable](images/01_compostable_unknown.png)

- **识别状态【需进一步确认】**：原图为黑色幼苗及“compostable”字样，带®；无法据此认定它是“任何人都可使用的通用标志”，也无法确认它一定属于European Bioplastics。
- **含义**：传达“可堆肥”环境属性，但没有独立说明商业或家庭堆肥条件。
- **可能适用标准**：塑料工业堆肥通常核查ASTM D6400；带塑料/聚合物涂层或添加剂的纸基制品可涉及ASTM D6868；纯纸制品不能机械套用上述标准。
- **使用前**：核实图形商标权人；核实成品适用标准、测试及所在州法规；若使用BPI等正式认证商标，须另行取得其许可。
- **风险**：不得将“原料可堆肥”直接宣传为“最终产品已认证”。

### 2.2 ② DIN-Geprüft HOME COMPOSTABLE

![原图2：DIN HOME](images/02_din_home.png)

- **机构【官方体系可核实】**：DIN CERTCO；家庭堆肥认证依据NF T51-800等相应方案。
- **作用**：验证特定认证范围内的材料/产品符合家庭堆肥要求，涉及生物降解、崩解、化学与生态安全等。
- **使用条件**：取得有效认证和商标使用权，核对证书编号、认证主体、产品型号及厚度/配方范围。
- **美国注意**：DIN HOME不自动等于TÜV Austria的OK compost HOME；加州对“Home Compostable”另有特定要求。
- **官方入口**：[DIN CERTCO](https://www.dincertco.de/)。

### 2.3 ③ Home Compostable AS 5810

![原图3：AS 5810](images/03_as5810.png)

- **体系**：澳大利亚AS 5810家庭堆肥标准，ABA管理相关认证标志。
- **特点**：家庭堆肥条件下评价生物降解、崩解及生态毒性（包括蚯蚓相关测试）。具体阈值、温度与适用范围以标准及认证方案为准。
- **使用条件**：认证/有效转授权；供应商持证不意味着品牌方可任意印标。
- **美国注意**：AS 5810不自动替代加州的OK compost HOME要求。
- **官方入口**：[ABA Certification](https://bioplastics.org.au/certification/)。

### 2.4 ④ FSC（森林管理委员会）

![原图4：FSC](images/04_fsc.png)

- **含义**：森林来源材料的管理及供应链追溯体系，不证明成品可堆肥、可降解或可回收。
- **常见标签**：FSC 100%、FSC Mix、FSC Recycled。类别与资格应由认证方确定，不得自行选用。
- **印标路径**：优先由符合FSC CoC要求的成品工厂在其认证范围内生产、完成商标审核；原纸供应商持证不代表任何下游加工厂都可贴标。
- **CPF特别条件【官方已核实】**：FSC路径要求商品为符合要求的认证成品并带有FSC标签；申请主体须持自己的FSC CoC或Promotional Licence；仅靠FSC获得CPF时，FSC认证材料至少占产品重量的50%。这是**CPF资格条件，不是所有FSC产品标签的通用门槛**。
- **注意**：原图中的“A000543”不能当成你自己的证书或标签授权编号。
- **官方入口**：[FSC证书查询](https://search.fsc.org/)｜[FSC电商可持续项目](https://connect.fsc.org/certification/ecommerce-sustainability-programs)。

### 2.5 ⑤ 蓝色SC圆形标志

![原图5：SC（待识别）](images/05_sc_unknown.png)

- **身份【未确认】**：不能可靠识别其商标权利人；**不能直接认定为SCS Global Services回收成分认证**。
- **处理**：向供应商索要矢量原图、证书名称、发证机构、证书编号及商标授权；未核实前不用于包装和Listing。
- **补充**：SCS回收成分认证是另一项值得了解的认证，需按SCS-103及适用方案核验再生材料比例；不能将本图当成SCS的认证标志。
- **官方入口**：[SCS Recycled Content](https://www.scsglobalservices.com/services/recycled-content-certification)。

### 2.6 ⑥ Biodegradable（绿色三叶图案）

![原图6：Biodegradable](images/06_biodegradable.png)

- **含义**：传达可生物降解声明；本图的权利归属未核实。
- **美国风险【官方已核实】**：FTC对未经限定的“Biodegradable”有严格举证要求；加州对塑料制品的降解相关营销用语另有严格限制。
- **建议**：不以“材料天然可降解”代替成品测试；没有明确降解环境、处置路径和科学证据时不建议使用。
- **官方入口**：[FTC环保声明摘要](https://www.ftc.gov/business-guidance/resources/environmental-claims-summary-green-guides)｜[CalRecycle标签法规](https://calrecycle.ca.gov/plastics/labeling/)。

### 2.7 ⑦ Compostable（果核/幼芽+圆形箭头）

![原图7：Compostable（待识别）](images/07_compostable_unknown.png)

- **身份【未确认】**：圆形箭头围绕果核或植物图案，无法确定是否为认证商标；不可直接宣称是“通用且无需授权”。
- **含义**：可堆肥相关宣传，但图形自身没有指明工业或家庭堆肥。
- **使用前**：核实商标权人、成品适用堆肥条件、证据及销售地法规。BPI、DIN、OK compost HOME均不能通过直接替换这个图案来表示已认证。

### 2.8 ⑧ Recyclable（追逐箭头）

![原图8：Recyclable](images/08_recyclable.png)

- **含义**：常见Mobius Loop（三角循环箭头）形式，传达可回收性声明；原图具体图形权利仍需核实。
- **是否必须认证**：美国不存在所有商品统一强制申请的“可回收Logo证书”；但声明必须有充分证据并符合州法。
- **FTC**：适当回收设施未覆盖至少60%的销售地区消费者或社区时，应限定回收声明。
- **加州SB 343**：对追逐箭头及回收声明有特定限制；2026年相关法院禁令及后续执行状态应在包装投产前再查官方公告，不以单一新闻作为最终法律意见。
- **官方入口**：[CalRecycle Recycling Labels](https://calrecycle.ca.gov/wcs/recyclinglabels/)。

## 第三章｜核心认证体系与标准对照

| 体系/标准 | 核心属性 | 对象/使用边界 | Logo使用 |
|---|---|---|---|
| ASTM D6400 | 商业堆肥 | 主要用于适用塑料产品的标准评价 | 标准本身不授予Logo |
| ASTM D6868 | 商业堆肥 | 塑料/聚合物涂层或添加剂与纸等基材结合的终产品 | 标准本身不授予Logo |
| BPI Commercial | 商业堆肥第三方认证 | 产品、组件、材料需在其认证范围内 | 需有效许可或转授权 |
| BPI Commercial & Home | 商业及家庭堆肥 | 2025年推出；家庭方案基于NF T51-800，商业认证为前提 | 需有效许可；不保证所有州可直接声明 |
| DIN CERTCO HOME | 家庭堆肥认证 | 按DIN认证方案及适用产品范围 | 需认证及商标许可 |
| TÜV Austria OK compost HOME | 家庭堆肥认证 | 加州家庭堆肥声明的重要核查对象 | 需认证及商标许可 |
| ABA AS 5810 | 家庭堆肥认证 | 澳大利亚标准及ABA计划 | 需认证或转授权 |
| FSC CoC | 森林材料供应链 | 企业、工厂、交易和成品标签 | 按FSC商标规则审核 |
| SCS-103 | 再生材料含量 | 包装、纸张、塑料等适用产品 | 按SCS认证及商标规则 |

**重要更新【官方已核实】**：BPI现有Commercial Only和Commercial & Home两类认证。BPI以ASTM D6400作为商业认证基础标准，符合条件时还可选择评估D6868或D8410；具体由技术审核确定，不能简单理解成“纸制品一律做D6868”。来源：[BPI认证](https://bpiworld.org/Certification)｜[BPI商业堆肥方案](https://bpiworld.org/compostability-certification)。

**BPI证书核验**：[BPI产品数据库](https://bpiworld.org/find-certified-products)，可按公司、产品及SKU检索；数据库对家庭认证有单独字段。**部件认证不等于成品认证**，BPI明确禁止用认证标志暗示未认证成品已经认证。[BPI标志使用要求](https://bpiworld.org/using-the-bpi-mark)。

## 第四章｜美国法规与亚马逊政策

### 4.1 FTC Green Guides（联邦层面）

- **可堆肥**：需有可靠证据，说明在适用堆肥条件下分解；对设施可获得性和必要限制应作适当说明。
- **可降解**：无条件声明的举证门槛很高，尤其常规填埋处理下的固体废弃物。
- **可回收**：不能仅因实验室可回收便笼统声称消费者能够回收。
- **认证标识**：认证不替代对具体环境利益声明的证据；不应使用无法说明依据的宽泛“绿色”印章。

来源：[FTC Environmental Claims](https://www.ftc.gov/business-guidance/resources/environmental-claims-summary-green-guides)。

### 4.2 加州堆肥与降解标签

CalRecycle当前说明：

- 可堆肥塑料：ASTM D6400-19；
- 塑料涂层纤维：ASTM D6868-19；
- 标注Home Compostable的消费品：须认证符合OK compost HOME要求；
- 可堆肥消费品还涉及总有机氟低于100 ppm、标签可识别、与有机废弃物回收相关等条件；
- 部分合成材料涉及延长至2027-06-30的后续要求，具体应按法定范围确认。

**不能推出**：所有纸制品都必须做ASTM D6400，或者所有可堆肥产品都可以自由使用Home Compostable字样。

来源：[CalRecycle Truth-in-Labeling](https://calrecycle.ca.gov/plastics/labeling/)。

### 4.3 加州SB 343与回收箭头

SB 343针对回收声明和追逐箭头设置了特殊要求。2026年相关诉讼及初步禁令影响执行，**包装定稿前必须重新核对CalRecycle公告和有效法院命令**。不要简单把“FTC 60%设施可获得性”与加州SB 343具体回收判定标准当成同一个测试。

来源：[CalRecycle Recycling Labels](https://calrecycle.ca.gov/wcs/recyclinglabels/)。

### 4.4 Amazon Climate Pledge Friendly（CPF）

- **概念**：亚马逊展示合格商品可持续属性的项目，不是企业自行印Logo就能获得的资格。
- **FSC路径【官方已核实】**：须有符合要求的FSC认证成品及标签；申请方拥有自己的FSC CoC或Promotional Licence；FSC认证材料按重量至少50%才可仅凭FSC取得CPF资格；还要遵守商品排除类别及平台审核。
- **BPI/SCS/其他路径【待逐项核实】**：不能因为认证机构存在，就断言具体SKU一定符合CPF；应以当期亚马逊认可计划、SKU适用范围及数据提交流程为准。
- **商业结果【不能保证】**：CPF标识可能增强识别度，但不等于固定排名加权或销量增长。

FSC官方路径：[FSC eCommerce Sustainability Programs](https://connect.fsc.org/certification/ecommerce-sustainability-programs)。

## 第五章｜中国供应商证书核验与认证申请SOP

### 5.1 先向供应商索取

1. 营业主体、实际制造厂名称、工厂地址；
2. 证书PDF原件、证书编号、认证机构、有效期、官网查询入口；
3. 证书覆盖产品名称、SKU、材料、配方、最大厚度/克重及颜色/印刷限制；
4. 成品测试报告及样品一致性证明；
5. FSC：CoC代码、交易文件中的FSC声明、成品标签审核记录；
6. 堆肥产品：涂层、油墨、胶水、添加剂及总有机氟等相关资料；
7. 书面Logo使用授权、拟印刷图稿审批记录；
8. 产品与外包装分别适用哪些环保声明。

### 5.2 核验步骤

**第一步**：确认具体产品与目标市场（全美/加州/其他州）；**第二步**：在发证机构数据库核实证书；**第三步**：逐项对照实际SKU和配方；**第四步**：确认供应链及品牌方是否有商标使用资格；**第五步**：核对FTC和州法；**第六步**：提交Logo排版审批；**第七步**：保留出货批次、采购凭证、认证文件和最终包装稿；**第八步**：如申请CPF，再按该认证项目的官方路径提交。

### 5.3 供应商问询模板

> 请提供拟供产品的环保认证证书及官网查询链接，并确认认证是否覆盖我司具体SKU、成品配方、厚度/克重、颜色、印刷和胶黏剂。请说明贵司是否具有在我司品牌包装和Amazon Listing中使用对应Logo的授权，以及标签稿需要由谁审核。若仅原材料获认证，请明确最终成品是否另需认证。请附认证有效期、商标授权及最近的检测资料。

### 5.4 红线

- 供应商只发一张Logo截图，没有证书编号；
- 证书属于原材料厂，成品加工厂无法证明认证链；
- 证书型号与采购SKU不一致；
- 把工业堆肥认证宣传成家庭堆肥；
- 用FSC证明“可降解”，或用SCS再生含量证明“可回收”；
- 把供应商证书编号直接写成自有品牌证书；
- 先印刷、后申请认证。

## 第六章｜产品开发场景与认证优先级

> 下表为【商业建议】，不是强制法规清单；实际取决于成分、用途、销售地区及宣称内容。

| 产品 | 优先核实 | 可选方向 | 重点风险 |
|---|---|---|---|
| 牛皮纸卷/礼品包装纸 | FSC供应链与成品标签 | Recyclable、再生含量 | 油墨、覆膜、回收路径；不宜空泛声称可降解 |
| 牛皮纸胶带 | 纸基FSC适用性、胶黏剂组成 | 可回收/堆肥成品验证 | 胶水可能影响整卷回收和堆肥结论 |
| 纸袋/纸盒 | FSC、可回收性 | SCS再生含量 | 覆膜、窗口膜、烫金和复合结构 |
| 纸杯/纸盘 | 食品接触合规 + 成品结构 | BPI、FSC | 涂层及油墨；认证范围与实际规格一致性 |
| PLA袋/可堆肥袋 | ASTM适用性、BPI及州法 | 家庭堆肥路径 | 不可将工业堆肥当作家庭堆肥；加州标签细则 |
| 纤维模塑餐具 | 食品接触及配方审查 | BPI、FSC、再生含量 | 添加剂、涂层、PFAS相关要求 |

### 6.1 认证投入决策原则

- **优先做能支持核心卖点的认证**，不是追求包装Logo数量。
- **优先复用合法且覆盖成品的供应商认证路径**，但要核实授权及供应链条件。
- **高成本认证先验证需求**：目标消费者是否搜索该环保属性、竞品是否靠此形成溢价、认证费用与毛利能否匹配。
- **没有确定的费用与周期**：不得把通用网络报价当成项目预算；至少向两家合格认证服务方获取书面报价。

## 第七章｜官方来源、核验状态与更新记录

### 7.1 官方资料索引

| 主题 | 官方入口 | 当前用途 |
|---|---|---|
| FTC环保声明 | https://www.ftc.gov/business-guidance/resources/environmental-claims-summary-green-guides | 降解、可堆肥、可回收声明边界 |
| 加州降解/堆肥标签 | https://calrecycle.ca.gov/plastics/labeling/ | ASTM、OK compost HOME及附加条件 |
| 加州回收标识 | https://calrecycle.ca.gov/wcs/recyclinglabels/ | SB 343与执行状态 |
| FSC CPF路径 | https://connect.fsc.org/certification/ecommerce-sustainability-programs | FSC申请主体、标签及50%门槛 |
| FSC证书核验 | https://search.fsc.org/ | CoC证书状态 |
| BPI认证 | https://bpiworld.org/Certification | 商业及家庭堆肥方案 |
| BPI产品库 | https://bpiworld.org/find-certified-products | 成品及SKU核验 |
| BPI标志授权 | https://bpiworld.org/using-the-bpi-mark | 商标许可、成品范围 |
| DIN CERTCO | https://www.dincertco.de/ | DIN HOME认证方案 |
| ABA | https://bioplastics.org.au/certification/ | AS 5810认证 |
| SCS | https://www.scsglobalservices.com/services/recycled-content-certification | 再生材料含量认证 |

### 7.2 待确认清单

- [ ] 原图①黑色幼苗Logo权利人及注册商标信息。
- [ ] 原图⑤蓝色SC圆形Logo的准确身份。
- [ ] 原图⑦圆形Compostable图案的准确身份。
- [ ] DIN HOME、AS 5810、BPI、SCS在CPF中的具体最新准入范围。
- [ ] 加州SB 343诉讼及初步禁令在实际包装投产日的最新状态。
- [ ] 目标产品的认证报价、周期、样品数量及配方变更后的复审要求。
- [ ] 正式印刷所需的认证机构授权原版Logo文件。

### 7.3 版本记录

- **V1.0（2026-10-13）**：建立7章知识库；整合8个原图裁剪、FTC/CalRecycle/FSC/BPI官方资料；纠正“FBA所有降解包装必须D6400认证”“FSC 50%是通用贴标门槛”“原材料证书等于成品认证”等不可靠说法。

---

**使用提醒**：本文件为产品开发研究资料，不构成法律意见、认证授权或平台审批承诺。正式商业使用前，请以产品适用的最新标准、州法、认证方案、商标许可和亚马逊实际审核结果为准。
